void setup() {
  Serial.begin(BAUD);

  Serial.println();
  Serial.println("Propane Level Scale\n");

  // If EEPROM initialization fails, we will continue with default values.
  // If EEPROM initializes succeeds, we will attempt to load saved values.
  // If load fails, we fall back to defaults and attempt to save those defaults to EEPROM for future use.
  eepromReady = EEPROM.begin(EEPROM_SIZE_BYTES);

  if (!eepromReady) {
    Serial.println("EEPROM init failed. Using default calibration factor, tank tare, and max propane weight.");
    calibration_factor = DEF_CALIBRATION_FACTOR;
    tankTare = DEF_TANK_TARE;
    maxPropaneLbs = MAX_PROPANE_LBS;
  } else {
    float storedCalibration = DEF_CALIBRATION_FACTOR;
    if (loadCalibrationFromEeprom(storedCalibration)) {
      calibration_factor = storedCalibration;
      Serial.print("Loaded calibration factor from EEPROM: ");
      Serial.println(calibration_factor, 2);
    } else {
      calibration_factor = DEF_CALIBRATION_FACTOR;
      if (!saveCalibrationToEeprom(calibration_factor)) {
        Serial.println("Failed to initialize default calibration in EEPROM.");
      } else {
        Serial.println("Initialized default calibration in EEPROM.");
      }
    }

    float storedTankTare = DEF_TANK_TARE;
    if (loadTankTareFromEeprom(storedTankTare)) {
      tankTare = storedTankTare;
      Serial.print("Loaded tank tare from EEPROM: ");
      Serial.print(tankTare, 2);
      Serial.println(" lbs");
    } else {
      tankTare = DEF_TANK_TARE;
      if (!saveTankTareToEeprom(tankTare)) {
        Serial.println("Failed to initialize default tank tare in EEPROM.");
      } else {
        Serial.println("Initialized default tank tare in EEPROM.");
      }
    }

    float storedMaxPropane = MAX_PROPANE_LBS;
    if (loadMaxPropaneWeightFromEeprom(storedMaxPropane)) {
      maxPropaneLbs = storedMaxPropane;
      Serial.print("Loaded max propane weight from EEPROM: ");
      Serial.print(maxPropaneLbs, 2);
      Serial.println(" lbs");
    } else {
      maxPropaneLbs = MAX_PROPANE_LBS;
      if (!saveMaxPropaneWeightToEeprom(maxPropaneLbs)) {
        Serial.println("Failed to initialize default max propane weight in EEPROM.");
      } else {
        Serial.println("Initialized default max propane weight in EEPROM.");
      }
    }
  }

  scale.begin(DOUT_PIN, CLK_PIN);

  // project not intended for continuous operation
  // always starting fresh avoids issues with long term stability issues
  Serial.println();
  Serial.println("Setup requires an empty scale before initial tare.");

  while (!waitForUserConfirmation("Setup confirmation cancelled.")) {
    Serial.println("Cannot continue setup tare until all weight is removed.");
  }

  scale.set_scale();
  scale.tare();

  Serial.println("Scale is tared and ready.\n");
  Serial.println("Send 'a' to enter automatic calibration mode");
  Serial.println("Send 'e' to display saved EEPROM values");
  Serial.println("Send 'l' to display one propane reading");
  Serial.println("Send 'm' to enter manual calibration mode");
  Serial.println("Send 'p' to set propane tank tare");
  Serial.println("Send 'w' to set maximum legal propane weight");
  Serial.println("Send 'z' to re-zero scale with no weight on it");
}